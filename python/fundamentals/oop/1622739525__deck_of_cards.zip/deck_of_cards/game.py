from classes.deck import Deck

bicycle = Deck()

bicycle.show_cards()